//import Layout  from './Components/layout/layout'
import './App.css';
import Form from './Components/Signin_1/Form'
import Form2 from './Components/Signin_2/Form2'
import Form3 from './Components/Signin_3/Form3'
import Signup from './Components/SignUp/signup'
import Layout from './Components/layout/layout'
import Password from './Components/Password_recovery/pwd'



function App() {
  return (
    <div>
    {/* <Form/> */}
    <Form2/>
    {/* <Form3/> */}
    {/* <Signup/> */}
    {/* <Layout/> */}
    {/* <Password /> */}
    </div>
  );
}

export default App;
