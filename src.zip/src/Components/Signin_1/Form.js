// import { Button } from "bootstrap";
import { Component } from "react";
//import { Link } from 'react-router';
//import { Link } from "react-router-dom";
//import 'bootstrap/dist/css/bootstrap.min.css';
import './Form.css';
// import { Glyphicon } from 'react-bootstrap';
import { FcGoogle } from 'react-icons/fc';
import { AiFillFacebook,AiFillCopyrightCircle } from 'react-icons/ai';
import cell from '../../Asset/images/cell.png';
// import Cell1 from '../Asset/images/Cell1.png';


class Form extends Component {
    render() {
        return (
            <div className="container-fluid">
                <div className="row">

                    <header className="nav">
                        <div className="head container-fluid">
                            <span>Copyright<AiFillCopyrightCircle/> 1996-2021 YouShop Ltd. All rights reserved</span>
                            <span>Terms of Use - Privacy Policy - Link to Us</span>
                            {/* <span>content 1</span>
                            <span>content2 </span> */}
                        </div>
                    </header>

                    <section className="landing_screen col-lg-12">
                        <div className="row h-100">
                            <div className=" mobile_img col-lg-6">
                                <div className="row">
                                    <img src={cell} alt="Phone" />
                                </div>
                            </div>


                            <div className="signin col-sm-6">
                                <div className="">
                                    <h3>Welcome Back !</h3>
                                    <p>Online Grocery Shopping</p>
                                    <form>
                                        <div className="form-group mb-4">
                                            <label htmlFor="email"><strong>Email</strong></label><br></br>
                                            <input type="email" id="email" placeholder="Enter your email"  />
                                        </div>
                                        <div className="form-group mb-4">
                                            <label htmlFor="Password"><strong>Password</strong></label><br></br>
                                            <input type="Password" id="Password" placeholder="Enter your password" />
                                        </div>
                                        <div className="form-group mb-4">

                                            <div className="col-sm-12">
                                                <div className="row">
                                                    <div className="col-sm-6">
                                                        <div className="row d-flex align-items-center">
                                                            <input type="checkbox" className="keep-signed" name="signed" />
                                                            <label for="signed" className="mb-0">&nbsp; Keep me signed</label>
                                                        </div>
                                                    </div>


                                                    <div className="col-sm-6">
                                                        <div className="row d-flex justify-content-end">
                                                            <a href="/Forgot Password">Forgot Password?</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                    <button className="button-1"> Sign in</button>
                                    <div className="signin-divider mt-4 d-flex">
                                        Or<hr />
                                    </div>
                                    <br></br>
                                    <div>
                                        <button className="button-2"><FcGoogle />&nbsp; Continue with Google</button>
                                    </div>
                                    <br></br>
                                    <div>
                                        <button className="button-2"><AiFillFacebook />&nbsp; Continue with Facebook</button>
                                    </div>
                                    <br></br>
                                    <div>
                                        <p>Don't Have an Account? <a href="/Sign Up"> Sign Up</a> </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>


                </div>
            </div>
        );
    }
}

export default Form;



