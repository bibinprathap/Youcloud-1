import { Component } from 'react'


class layout extends Component {
    
    render() {
        let a=["india","pak", "dubai","china","australia","USA","UK"]
       
        
        const changeHandler =(event) =>{
            console.log(event.target.value)
        }
        return (
            // <select>{a.map( (i, indx)=>{ return <option key={indx} value={i}>{i}</option>})}</select>
            <select onChange={(event)=>{changeHandler(event)}}>{a.map( (i, indx)=>{ return <option key={indx} value={i} >{i}</option>})}</select>
        );
    }
}
//map(()=>{})
export default layout;